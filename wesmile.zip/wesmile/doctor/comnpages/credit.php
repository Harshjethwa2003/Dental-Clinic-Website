<div class="text-right">
          <div class="credits">
                <!--<a href="#">DrugHouse </a> by <a href="#">Worldsoft Technologies Pvt. Ltd.</a>-->
            </div>
        </div>