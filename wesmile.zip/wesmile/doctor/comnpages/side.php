 <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">                
                  <li class="active">
                      <a class="" href="index.php">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>
				  
				 
				  
				  
				  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_profile"></i>
                          <span>Appointment</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          
                          <li><a class="" href="view_myappointment.php">View My Appointments</a></li>
                          

                          
                      </ul>
                  </li> 
				  
				  
				   <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_profile"></i>
                          <span>Prescription</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          
                          <li><a class="" href="add_prescription.php">Add Prescription</a></li>
                           <li><a class="" href="view_prescription.php">View Prescription</a></li>

                          
                      </ul>
                  </li> 
				  
         <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_profile"></i>
                          <span>Profile</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="./doctor_profile_view.php">View Profile</a></li>                          
                          <li><a class="" href="./doctor_edit_profile.php">Update Profile</a></li>
                          <li><a class="" href="./changePassword.php">Change Password</a></li>

                          
                      </ul>
                  </li>  
                  
				  
				  
                 
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
     