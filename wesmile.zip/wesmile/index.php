<!DOCTYPE html>

<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->

<head>
    <title>We-Smile</title>
    <link rel="icon" type="image" href="./images/logo.jpg">
    <meta charset="utf-8">
    
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/animations.css">
    <link rel="stylesheet" href="css/fonts.css">
    <link rel="stylesheet" href="css/main.css" class="color-switcher-link">
    <link rel="stylesheet" href="css/shop.css">
    <script src="js/vendor/modernizr-2.6.2.min.js"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
</head>

<body>
   
    <div class="modal" tabindex="-1" role="dialog" aria-labelledby="search_modal" id="search_modal"> <button
            type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">
                <i class="rt-icon2-cross2"></i>
            </span>
        </button>
        <div class="widget widget_search">
            <form method="get" class="searchform search-form form-inline" action="./">
                <div class="form-group bottommargin_0"> <input type="text" value="" name="search" class="form-control"
                        placeholder="Search keyword" id="modal-search-input"> </div> <button type="submit"
                    class="theme_button">Search</button>
            </form>
        </div>
    </div>
    <!-- Unyson messages modal -->
    <div class="modal fade" tabindex="-1" role="dialog" id="messages_modal">
        <div class="fw-messages-wrap ls with_padding">
       
        </div>
    </div>
    <!-- eof .modal -->
    <!-- wrappers for visual page editor and boxed version of template -->
    <div id="canvas">
        <div id="box_wrapper">


            <!-- Header Start -->
            <?php include('./comnpages/header.php'); ?>
            <!--Header End -->


            <!-- Slider sections -->
            <section class="intro_section page_mainslider ds color">
                <div class="flexslider" data-dots="true" data-nav="false">
                    <ul class="slides">
                        <li> <img src="./images/slider/1.jpg" alt="">
                            <div class="container">
                                <div class="row">
                                    <div class="col-sm-12 text-center">
                                        <div class="slide_description_wrapper">
                                            <div class="slide_description">
                                                <div class="intro-layer with_corner_border with_padding huge-padding"
                                                    data-animation="slideExpandUp">

                                                    <h5 class="thin">Smile because you are looking at the Dentist</h5>
                                                    <h2 class="highlight"> EXPERTISE AND FRIENDLINESS </h2>
                                                    <p>Eliminate pain and discomfort<br>Rebuild and transform your
                                                        smile<br></p> <a href="searchDoctor.php"
                                                        class="theme_button color2 inverse margin_0">
                                                        Search Doctor
                                                    </a> <span class="bottom_corners"></span>
                                                </div>
                                            </div>
                                            <!-- eof .slide_description -->
                                        </div>
                                        <!-- eof .slide_description_wrapper -->
                                    </div>
                                    <!-- eof .col-* -->
                                </div>
                                <!-- eof .row -->
                            </div>
                            <!-- eof .container -->
                        </li>
                        <li> <img src="./images/slider/2.jpg" alt="">
                            <div class="container">
                                <div class="row">
                                    <div class="col-sm-12 text-center">
                                        <div class="slide_description_wrapper">
                                            <div class="slide_description">
                                                <div class="intro-layer with_corner_border with_padding huge-padding"
                                                    data-animation="slideExpandUp">
                                                    <h5 class="thin"> We will Help You </h5>
                                                    <h2 class="highlight"> To Live with a Healthy smile </h2>
                                                    <p> Our mission is to Help you live a normal and pain-free life <br>
                                                        Your oral health is an important part of your overall wellbeing
                                                    </p> <a href="searchDoctor.php"
                                                        class="theme_button color2 inverse margin_0">
                                                        Search Doctor
                                                    </a> <span class="bottom_corners"></span>
                                                </div>
                                            </div>
                                            <!-- eof .slide_description -->
                                        </div>
                                        <!-- eof .slide_description_wrapper -->
                                    </div>
                                    <!-- eof .col-* -->
                                </div>
                                <!-- eof .row -->
                            </div>
                            <!-- eof .container -->
                        </li>
                        <li> <img src="./images/slider/3.jpg" alt="">
                            <div class="container">
                                <div class="row">
                                    <div class="col-sm-12 text-center">
                                        <div class="slide_description_wrapper">
                                            <div class="slide_description">
                                                <div class="intro-layer with_corner_border with_padding huge-padding"
                                                    data-animation="slideExpandUp">
                                                    <h5 class="thin"> We will make you </h5>
                                                    <h2 class="highlight"> Feel Great About Your Smile And Your
                                                        Dentist<br> </h2>
                                                    <p> Everything You Need Under One Roof<br> Your treatment plan will
                                                        perfectly match your needs, lifestyle, and goals. </p><a
                                                        href="searchDoctor.php"
                                                        class="theme_button color2 inverse margin_0">
                                                        Search Doctor
                                                    </a> <span class="bottom_corners"></span>
                                                </div>
                                            </div>
                                            <!-- eof .slide_description -->
                                        </div>
                                        <!-- eof .slide_description_wrapper -->
                                    </div>
                                    <!-- eof .col-* -->
                                </div>
                                <!-- eof .row -->
                            </div>
                            <!-- eof .container -->
                        </li>
                    </ul>
                </div>
                <!-- eof flexslider -->
            </section>

            <section>

            </section>

            <section id="features"
                class="ls section_padding_top_150 section_padding_bottom_130 columns_margin_bottom_30">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <h2 class="section_header">Why Choose Us?</h2> <a href="about.php"
                                class="theme_button color2 inverse min_width_button">About Us</a>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="teaser media hover_icon">
                                <div class="media-left">
                                    <div class="teaser_icon rounded main_bg_color size_small"> <i
                                            class="rt-icon2-diamond2"></i> </div>
                                </div>
                                <div class="media-body toppadding_10">
                                    <h5 class="hover-color2"><a href="#">24/7 Availability</a></h5>
                                    <p>The website services are available round the clock.</p>
                                </div>
                            </div>
                            <div class="teaser media hover_icon">
                                <div class="media-left">
                                    <div class="teaser_icon rounded main_bg_color size_small"> <i
                                            class="rt-icon2-cloud"></i> </div>
                                </div>
                                <div class="media-body toppadding_10">
                                    <h5 class="hover-color2"><a href="#">Travel free appointmnets</a></h5>
                                    <p>No more waiting in queue for getting an Appointment.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="teaser media hover_icon">
                                <div class="media-left">
                                    <div class="teaser_icon rounded main_bg_color size_small"> <i
                                            class="rt-icon2-tag2"></i> </div>
                                </div>
                                <div class="media-body toppadding_10">
                                    <h5 class="hover-color2"><a href="#">Discount</a></h5>
                                    <p>Book Appointment through the website and get amazing discounts.</p>
                                </div>
                            </div>
                            <div class="teaser media hover_icon">
                                <div class="media-left">
                                    <div class="teaser_icon rounded main_bg_color size_small"> <i
                                            class="rt-icon2-cloud"></i> </div>
                                </div>
                                <div class="media-body toppadding_10">
                                    <h5 class="hover-color2"><a href="#">User Satisfaction</a></h5>
                                    <p>Users are provided with best services possible.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            

        
            <!-- Start Footer -->
            <?php include('./comnpages/footer.php'); ?>
            <!-- End Footer -->


        </div>
        <!-- eof #box_wrapper -->
    </div>
    <!-- eof #canvas -->
    <script src="js/compressed.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript">
    $(document).ready(function() {
        var itemsMainDiv = ('.MultiCarousel');
        var itemsDiv = ('.MultiCarousel-inner');
        var itemWidth = "";

        $('.leftLst, .rightLst').click(function() {
            var condition = $(this).hasClass("leftLst");
            if (condition)
                click(0, this);
            else
                click(1, this)
        });

        ResCarouselSize();




        $(window).resize(function() {
            ResCarouselSize();
        });

        //this function define the size of the items
        function ResCarouselSize() {
            var incno = 0;
            var dataItems = ("data-items");
            var itemClass = ('.item');
            var id = 0;
            var btnParentSb = '';
            var itemsSplit = '';
            var sampwidth = $(itemsMainDiv).width();
            var bodyWidth = $('body').width();
            $(itemsDiv).each(function() {
                id = id + 1;
                var itemNumbers = $(this).find(itemClass).length;
                btnParentSb = $(this).parent().attr(dataItems);
                itemsSplit = btnParentSb.split(',');
                $(this).parent().attr("id", "MultiCarousel" + id);


                if (bodyWidth >= 1200) {
                    incno = itemsSplit[3];
                    itemWidth = sampwidth / incno;
                } else if (bodyWidth >= 992) {
                    incno = itemsSplit[2];
                    itemWidth = sampwidth / incno;
                } else if (bodyWidth >= 768) {
                    incno = itemsSplit[1];
                    itemWidth = sampwidth / incno;
                } else {
                    incno = itemsSplit[0];
                    itemWidth = sampwidth / incno;
                }
                $(this).css({
                    'transform': 'translateX(0px)',
                    'width': itemWidth * itemNumbers
                });
                $(this).find(itemClass).each(function() {
                    $(this).outerWidth(itemWidth);
                });

                $(".leftLst").addClass("over");
                $(".rightLst").removeClass("over");

            });
        }


        //this function used to move the items
        function ResCarousel(e, el, s) {
            var leftBtn = ('.leftLst');
            var rightBtn = ('.rightLst');
            var translateXval = '';
            var divStyle = $(el + ' ' + itemsDiv).css('transform');
            var values = divStyle.match(/-?[\d\.]+/g);
            var xds = Math.abs(values[4]);
            if (e == 0) {
                translateXval = parseInt(xds) - parseInt(itemWidth * s);
                $(el + ' ' + rightBtn).removeClass("over");

                if (translateXval <= itemWidth / 2) {
                    translateXval = 0;
                    $(el + ' ' + leftBtn).addClass("over");
                }
            } else if (e == 1) {
                var itemsCondition = $(el).find(itemsDiv).width() - $(el).width();
                translateXval = parseInt(xds) + parseInt(itemWidth * s);
                $(el + ' ' + leftBtn).removeClass("over");

                if (translateXval >= itemsCondition - itemWidth / 2) {
                    translateXval = itemsCondition;
                    $(el + ' ' + rightBtn).addClass("over");
                }
            }
            $(el + ' ' + itemsDiv).css('transform', 'translateX(' + -translateXval + 'px)');
        }

        //It is used to get some elements from btn
        function click(ell, ee) {
            var Parent = "#" + $(ee).parent().attr("id");
            var slide = $(Parent).attr("data-slide");
            ResCarousel(ell, Parent, slide);
        }

    });
    </script>
    <!-- 	<script
  src="https://code.jquery.com/jquery-3.5.1.min.js"
  integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
  crossorigin="anonymous"></script> -->
    

</body>

</html>