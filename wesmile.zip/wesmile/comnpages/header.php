<section
    class="page_topline cs main_color2 table_section table_section_sm section_padding_top_5 section_padding_bottom_5"
    style="background:#9ea8ad">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center text-sm-left">
                <marquee width="100%" direction="right" style="font-size:18px">
                    <i class="fa fa-clock-o rightpadding_5 " aria-hidden="true"></i> Opening Hours: Mon - Sat 9:00 -
                    21:00 &nbsp;&nbsp; | &nbsp;&nbsp; Get 10% off on online booking
                </marquee>

            </div>
</section>
<!-- Menue sections -->
<section class="header1">
    <nav class="navbar navbar-inverse" style="margin-bottom:0;background:#19bcdb;">
        <!-- style="padding-top: 20px; padding-bottom: 20px;" -->
        <div class="container-fluid" style="padding-top: 15px; padding-bottom: 15px;">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand " href="index.php"><span
                        style="font-weight: bold;color:#ffffff; font-size: 32px;font-family: 'Times New Roman', Times, serif; ">We-Smile
                        Dental Clinic</span></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav" style="margin-left:110px;">

                    
                    <li style="font-size: 18px;"><a href="searchDoctor.php">Search Doctor</a></li>
                    <li style="font-size: 18px;"><a href="contact.php">Contact</a></li>
                    <li style="font-size: 18px;"><a href="blog.php">Blogs</a></li>
                    <li style="font-size: 18px;"><a href="about.php">About Us</a></li>
                    
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li style="font-weight: bold;"><a href="./doctor/doctorlogin.php"><span
                                class="glyphicon glyphicon-user"></span> Doctor</a></li>
                    <li style="font-weight: bold;"><a href="patientlogin.php"><span
                                class="glyphicon glyphicon-log-in"></span> Patient</a></li>
                </ul>
            </div>
        </div>
    </nav>
</section>