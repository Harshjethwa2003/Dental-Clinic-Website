<?php 
	
	$conn = mysqli_connect("localhost","root","","doctors_appointment");

	 
?>	