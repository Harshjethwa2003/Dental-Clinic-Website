<section class="ds color darker page_copyright section_padding_15">
<div class="container">
        <div class="row">
            

<link rel="stylesheet" href="mystyle.css">

<script src="myscript.js"></script>

<head>
  
  <style>
    .contact-wrapper {
      display: flex;
      justify-content: center; /* Center elements horizontally */
      align-items: center; /* Center elements vertically */
      width: fit-content; /* Adjust width as needed */
      margin: 20px auto; /* Add margin for spacing */
    }

    .dental-logo {
      margin-right: 20px; /* Adjust as needed */
      width: 110px;
      border-radius: 10px; /* Adjust logo width as needed */
    }

    .contact-info {
      text-align: left; /* Adjust text alignment as needed */
    }

    .contact-info p {
      margin-bottom: 5px; /* Add spacing between contact details */
    }
  </style>
</head>
<body>
  <div class="contact-wrapper">
    <a href="./"> <img src="./images/footer.png"  class="dental-logo"  class="img-rounded"><a>
    <div class="contact-info">
      <h4>Contact Us</h4>
      <p><i class="fa fa-map-marker highlight"></i> Address: Parbat Nagar, Dahisar East, Mumbai</p>
      <p><i class="fa fa-phone highlight"></i> 18001801900</p>
      <p><i class="fa fa-pencil highlight"> </i><a href="mailto:wesmile@gmail.com"></i> Email: wesmile@gmail.com</a></p>
    </div>
  </div>


  <section>
    
            <div class="col-sm-12 text-center" style="align">
                <p class="fontsize_12">&copy; Copyright <?php echo date("Y"); ?> All Rights Reserved.</p>
                <p class="fontsize_12">Developed By : <a href="#" target="_blank">WE-SMILE DENTAL CLINIC</a> </p>
            </div>
       
</section>
