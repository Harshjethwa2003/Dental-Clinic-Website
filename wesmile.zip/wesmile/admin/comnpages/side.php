 <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">                
                  <li class="active">
                      <a class="" href="index.php">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>
				  
				 
				  
				  
          <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_profile"></i>
                          <span>Appoinments</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          
                          <li><a class="" href="admin_doctor_app.php">Pending Appointment</a></li>                   
                          <li><a class="" href="admin_doctor_app_accept.php">Accepted Appointment</a></li>                   
                          <li><a class="" href="admin_doctor_app_reject.php">Rejected Appointment</a></li>                   
                          
                      </ul>
                  </li> 
          <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_profile"></i>
                          <span>Doctors</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          
                          <li><a class="" href="admin_Doctors.php">All Doctor</a></li> 
	 <li><a class="" href="admin_Doctor_add.php">Add Doctor</a></li> 						
                          
                      </ul>
                  </li> 
				 <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_profile"></i>
                          <span>Patient</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="./admin_allPatient.php">All Patient</a></li>                          
                          <li><a class="" href="./admin_patient_add.php">Add Patient</a></li>                    
                          
                      </ul>
                  </li>  
				  
				  
	 <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_profile"></i>
                          <span>Clinic</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="./admin_allClinic.php">All Clinic</a></li>                          
                          <li><a class="" href="./admin_clinic_add.php">Add Clinic</a></li>                    
                          
                      </ul>
                  </li>  			  
				  
				  
				    

                		 <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_profile"></i>
                          <span>User Query</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="allcontact.php">Contact Msg.</a></li>                          
                                             
                          
                      </ul>
                  </li> 




 <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_profile"></i>
                          <span>Post</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="addpost.php">Add Post</a></li>                          
                          <li><a class="" href="managepost.php">Manage Post</a></li>                    
                          
                      </ul>
                  </li>  



				  
 
                  
				  
				  
                 
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
     