 <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">                
                  <li class="active">
                      <a class="" href="index.php">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>
				  
				 
				  
				  
				  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_profile"></i>
                          <span>Appointment</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          
                          <li><a class="" href="admin_doctor_app.php">View Appointment</a></li>
                          <li><a class="" href="admin_doctor_app_visited.php">Visited</a></li>
                          <li><a class="" href="admin_doctor_app_cancel.php">Cancel</a></li>

                          
                      </ul>
                  </li> 
         <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_profile"></i>
                          <span>Profile</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="./doctor_profile_view.php">View Profile</a></li>                          
                          <li><a class="" href="./admin_Doctors_update.php">Update Profile</a></li>
                          <li><a class="" href="./changePassword.php">Change Password</a></li>

                          
                      </ul>
                  </li>  
                  
				  
				  
                 
              </ul>
          
          </div>
      </aside>
     