<?php
require('../comnpages/config.php');
            
	       
			//echo $clinic_id=$_POST['clinic_id']; 
			$did=$_POST['d_id']; 
			$name=$_POST['name'];
			$addr=$_POST['addr'];
			$time_mon_sat=$_POST['time_mon_sat'];
			$time_sun=$_POST['time_sun'];
			//echo $file_name=$_FILES['image']['name'];
			$con_no=$_POST['con_no'];
			$mob_no=$_POST['mob_no'];
			
			 
			
			
	$sql="INSERT INTO clinics(d_id,name,address,timing_ms,timing_sun,contact_no,mobile_no) 
	VALUES ('$did','$name','$addr','$time_mon_sat','$time_sun','$con_no','$mob_no')";

	
	
     mysqli_Query($conn,$sql);

     
	

	
		echo '<script type="text/javascript">                
               window.location = "../admin_allDoctors.php?" 
			 </script>';



?>