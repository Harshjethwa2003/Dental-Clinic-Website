-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2023 at 09:00 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctors_appointment`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--
DROP TABLE IF EXISTS appointment;
CREATE TABLE `appointment` (
  `id` int(5) NOT NULL,
  `patientemail` varchar(50) DEFAULT NULL,
  `doctoremail` varchar(50) DEFAULT NULL,
  `disease` varchar(40) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `apptime` varchar(50) DEFAULT NULL,
  `appdate` varchar(50) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `patientemail`, `doctoremail`, `disease`, `description`, `apptime`, `appdate`, `status`) VALUES
(7, 'ansh@gmail.com', 'deepika@gmail.com', 'Tooth Sensitivity', 'pain to your teeth from cold drinks, sweets, hot drinks, cold air, or ice creams', '01:00', '2023-03-11', 'Accept'),
(8, 'zeal@gmail.com', 'stanly@gmail.com', '', 'Bad breath\r\nBlack or brown spots on your teeth\r\nAn unpleasant taste in your mouth', '12:00', '2023-03-12', 'Accept'),
(9, 'tisha@gmail.com', 'rita@gmail.com', 'Oral Cancer', 'Growth in your mouth', '13:00', '2023-03-20', 'Reject'),
(10, 'meet@gmail.com', 'ajaygupta@gmail.com', 'Gum Bleeding', 'Gum Bleeding', '01:00', '2023-03-22', 'Accept'),
(11, 'keven@gmail.com', 'amitarora@gmail.com', '', 'Stained Teeth', '12:00', '2023-03-20', 'Accept'),
(12, 'bhavya@gmail.com', 'rita@gmail.com', 'Cavities', 'Cavities\r\n', '14:00', '2023-04-01', 'Pending'),
(13, 'dharmik@gmail.com', 'stanly@gmail.com', 'Chipped Tooth', 'Chipped Tooth', '15:00', '2023-03-26', 'Pending'),
(14, 'dharmik@gmail.com', 'charuajmera@gmail.com', 'Impacted Teeth', 'Impacted Teeth', '16:00', '2023-03-19', 'Reject');

-- --------------------------------------------------------

--
-- Table structure for table `blogpost`
--
DROP TABLE IF EXISTS blogpost;
CREATE TABLE `blogpost` (
  `id` int(5) NOT NULL,
  `posttitle` varchar(300) DEFAULT NULL,
  `postdetail` longtext DEFAULT NULL,
  `image` longtext DEFAULT NULL,
  `postdate` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blogpost`
--

INSERT INTO `blogpost` (`id`, `posttitle`, `postdetail`, `image`, `postdate`) VALUES
(3, 'Talking about a Disease', '<h3>Oral and Maxillofacial Surgeon:</h3>\r\n\r\n<p>These dental specialty treats problems related to the hard and soft tissues of your face, mouth, and jaw. You don&rsquo;t need this type of dental specialist for every kind of oral surgery. Oral and maxillofacial surgeons perform more complex procedures or procedures requiring deep levels of sedation beyond nitrous oxide or&nbsp;<a href=\"https://www.deltadentalwa.com/blog/entry/2018/08/laughing-gas-works\" target=\"_blank\">laughing gas</a>. In fact, oral surgeons are the only health care professionals, other than anesthesiologists, who administer all levels of sedation. Specialized procedures performed by oral surgeons include tooth extractions, corrective jaw surgery, and cleft lip or cleft palate surgery.</p>\r\n', 'images/Post/post.jpg', '09-03-23');

-- --------------------------------------------------------

--
-- Table structure for table `clinics`
--
DROP TABLE IF EXISTS clinics;
CREATE TABLE `clinics` (
  `clinic_id` int(100) NOT NULL,
  `d_id` int(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `location` varchar(150) DEFAULT NULL,
  `timing_ms` varchar(200) NOT NULL,
  `timing_sun` varchar(200) NOT NULL,
  `contact_no` varchar(200) NOT NULL,
  `mobile_no` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clinics`
--

INSERT INTO `clinics` (`clinic_id`, `d_id`, `name`, `address`, `location`, `timing_ms`, `timing_sun`, `contact_no`, `mobile_no`) VALUES
(0, 36, 'Healthy Smiles', 'Mira Road', 'Mumbai', '10am-6pm', '9am-12pm', '9776545670', '8778677256'),
(0, 37, 'Dev Dental Clinic', 'Kandivali', 'Mumbai', '10am-6pm', '9am-12pm', '9561618210', '7867875275'),
(0, 38, 'Arora Clinic', 'Ville Parle', 'Mumbai', '10am-6pm', '9am-12pm', '9776545670', '7675762654'),
(0, 39, 'Dental studio', 'Andheri', 'Mumbai', '10am-6pm', '9am-12pm', '9776545670', '7685757645'),
(0, 40, 'Datta Clinic', 'Thane', 'Maharashtra', '10am-6pm', '9am-12pm', '9776545670', '8675766545'),
(0, 42, 'Alpha Dental Care', 'Navi Mumbai', 'Maharashtra', '10am-6pm', '9am-12pm', '9561618210', '7675465445'),
(0, 43, 'Dental hub', 'Churchgate ', 'Mumbai', '10am-6pm', '9am-12pm', '987654321', '6576576669');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_list`
--
DROP TABLE IF EXISTS doctor_list;
CREATE TABLE `doctor_list` (
  `did` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `speciality` varchar(100) NOT NULL,
  `fees` varchar(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `description` varchar(1500) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `password` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_list`
--

INSERT INTO `doctor_list` (`did`, `name`, `image`, `speciality`, `fees`, `address`, `description`, `emailid`, `contact`, `password`) VALUES
(36, 'Dr. Jariwala', 'images/Doctors/Jariwala.jpg', 'Endodontist, Orthodontist', '500', 'Mira Road', 'Working experience of 6 years', 'jariwala@gmail.com', '8767544299', '123456'),
(37, 'Dr. Ajay Gupta', 'images/Doctors/aman_singla.jpeg', 'Oral and Maxillofacial Surgeon', '750', 'Kandivali, Mumbai', '7 years of work experience with Synergy Dental Clinics', 'ajaygupta@gmail.com', '7986552899', '123456'),
(38, 'Dr. Amit Arora', 'images/Doctors/Amit.jpg', 'Pediatric Dentist', '800', 'Ville Parle', '4 Years of Working Experience. Deals with Child’s oral health like a pediatrician.', 'amitarora@gmail.com', '8767544299', '123456'),
(39, 'Dr. Charu Ajmera', 'images/Doctors/charu.jpg', 'Periodontist - Gum Specialist', '800', 'Andheri, Mumbai', '9 years of working experience Prevention, diagnosis, and treatment of diseases affecting the gums and other structures that support the teeth.', 'charuajmera@gmail.com', '8767544299', '123456'),
(40, 'Dr. Rita Datta', 'images/Doctors/ritadutt.jpg', 'Endodontist - Root Canal Specialist', '1000', 'Thane, Navi Mumbai', 'Experience of 10 years. An endodontist is a type of dentist who diagnoses and treats problems within this sensitive interior.', 'rita@gmail.com', '9756452468', '123456'),
(42, 'Dr. Stanly Dsouza', 'images/Doctors/Stanly.jpg', 'Orthodontist, Pediatric Dentist, Periodontist', '900', 'Navi Mumbai', '7 years of working experience ||  An orthodontist is a dental specialist who corrects the position of your teeth and jaws. A pediatric dental specialist is to a child’s oral health like a pediatrician is to their physical health.', 'stanly@gmail.com', '9876356562', '123456'),
(43, 'Dr. Deepika Seth', 'images/Doctors/deeepika.jpg', 'Prosthodontist - Replacement Specialist', '1200', 'Churchgate, Mumbai', 'Experience of 8 years||Prosthodontists restore and replace lost or damaged teeth. ', 'deepika@gmail.com', '9876356562', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--
DROP TABLE IF EXISTS patient;
CREATE TABLE `patient` (
  `id` int(5) NOT NULL,
  `patientname` varchar(50) DEFAULT NULL,
  `emailid` varchar(50) DEFAULT NULL,
  `contact` varchar(15) DEFAULT NULL,
  `password` varchar(10) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `image` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`id`, `patientname`, `emailid`, `contact`, `password`, `gender`, `address`, `image`) VALUES
(11, 'Tisha Jadwani', 'tisha@gmail.com', '9920982833', '123456', 'Female', 'Mira road, Mumbai', 'images/Patients/Tisha.jfif'),
(12, 'Zeal Saroliya', 'zeal@gmail.com', '8687765765', '123456', 'Female', 'Dombivali, Navi Mumbai', 'images/Patients/Zeal.jfif'),
(13, 'Keven Panchal', 'keven@gmail.com', '8768679468', '123456', 'Male', 'Malad, Mumbai', 'images/Patients/Keven.jpg'),
(14, 'Ansh Kevadiya', 'ansh@gmail.com', '9866554534', '123456', 'Male', 'Andheri,Mumbai', 'images/Patients/Ansh.jpg'),
(15, 'Bhavya Sangrajka', 'bhavya@gmail.com', '9878638744', '123456', 'Male', 'Kandivali,Mumbai', 'images/Patients/Bhavya.jfif'),
(17, 'Meet Savaliya', 'meet@gmail.com', '9824562899', '123456', 'Male', 'Dahisar,Mumbai', 'images/Patients/Meet.jfif'),
(18, 'Dharmik Pansuriya', 'dharmik@gmail.com', '9887763661', '123456', 'Male', 'Vashi,Navi Mumbai', 'images/Patients/Dharmik.jfif');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--
DROP TABLE IF EXISTS prescription;
CREATE TABLE `prescription` (
  `id` int(5) NOT NULL,
  `doctor` varchar(50) DEFAULT NULL,
  `patient` varchar(50) DEFAULT NULL,
  `symptom` varchar(200) DEFAULT NULL,
  `prescriptionmsg` longtext DEFAULT NULL,
  `pdate` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`id`, `doctor`, `patient`, `symptom`, `prescriptionmsg`, `pdate`) VALUES
(6, 'stanly@gmail.com', 'zeal@gmail.com', 'mouth ulcer', 'antimicrobial mouthwash.', '10-03-23'),
(7, 'stanly@gmail.com', 'dharmik@gmail.com', 'Teethache', 'Anti-inflammatory drugs such as ibuprofen, Advil, Motrin or naproxen work well with dental pain because they reduce inflammation', '18-03-23'),
(8, 'jariwala@gmail.com', 'tisha@gmail.com', 'Tooth sensitivity', 'After several applications, desensitizing toothpaste can sometimes help block pain associated with sensitive teeth. There are a variety of products available over-the-counter. ', '23-04-23'),
(9, 'charuajmera@gmail.com', 'zeal@gmail.com', 'Chipped Tooth', 'A crown if the chip is large or bonding with a strong resin material to replace the area that chipped', '23-04-23');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_feedback`
--
DROP TABLE IF EXISTS tbl_feedback;
CREATE TABLE `tbl_feedback` (
  `fbid` int(11) NOT NULL,
  `fbname` varchar(50) DEFAULT NULL,
  `fbphone` varchar(15) DEFAULT NULL,
  `fbemail` varchar(50) DEFAULT NULL,
  `fbsubject` varchar(150) DEFAULT NULL,
  `fbmessage` varchar(500) DEFAULT NULL,
  `fbproductid` varchar(50) DEFAULT NULL,
  `fbtime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_feedback`
--

INSERT INTO `tbl_feedback` (`fbid`, `fbname`, `fbphone`, `fbemail`, `fbsubject`, `fbmessage`, `fbproductid`, `fbtime`) VALUES
(8, 'Abhi', '123123123', 'abhi@gmail.com', 'testt', 'Gum Disease', NULL, '2022-10-29 22:14:35'),
(9, 'Dharmik', '1456876512', 'dharmik@gmail.com', 'Inquiry', 'Routecannel', NULL, '2022-11-26 16:51:25');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_logindetails`
--
DROP TABLE IF EXISTS tbl_logindetails;
CREATE TABLE `tbl_logindetails` (
  `user_id` int(11) NOT NULL,
  `did` int(11) NOT NULL DEFAULT 0,
  `user_name` varchar(50) DEFAULT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  `user_pass` varchar(20) DEFAULT NULL,
  `user_type` int(1) DEFAULT NULL COMMENT '1-User, 2-Employee, 3-Admin ',
  `status` int(1) NOT NULL DEFAULT 1 COMMENT '0-disable, 1-active',
  `createDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_logindetails`
--

INSERT INTO `tbl_logindetails` (`user_id`, `did`, `user_name`, `user_email`, `user_pass`, `user_type`, `status`, `createDate`) VALUES
(10, 0, 'Admin', 'admin', '1234', 3, 1, '2018-05-19 02:17:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogpost`
--
ALTER TABLE `blogpost`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor_list`
--
ALTER TABLE `doctor_list`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  ADD PRIMARY KEY (`fbid`);

--
-- Indexes for table `tbl_logindetails`
--
ALTER TABLE `tbl_logindetails`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `blogpost`
--
ALTER TABLE `blogpost`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `doctor_list`
--
ALTER TABLE `doctor_list`
  MODIFY `did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  MODIFY `fbid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_logindetails`
--
ALTER TABLE `tbl_logindetails`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
